# app.py

from flask import Flask, render_template
from flask import request, json, jsonify
from flask import send_file

import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

import sqlalchemy
from sqlalchemy import create_engine
import pymysql
pymysql.install_as_MySQLdb()

app = Flask(__name__)

# 由Heroku得到的連結網址是： mysql://spy1hmjzgmohf37t:qo1v8pi7y4kflyoj@wb39lt71kvkgdmw0.cbetxkdyhwsb.us-east-1.rds.amazonaws.com:3306/qm1f2chzljeztwqj
# 我們在Python中使用時，需要調整一下，讓sqlalchemy知道我們指定使用的mysql driver是用哪一套
mysql_db_url = 'mysql+pymysql://spy1hmjzgmohf37t:qo1v8pi7y4kflyoj@wb39lt71kvkgdmw0.cbetxkdyhwsb.us-east-1.rds.amazonaws.com:3306/qm1f2chzljeztwqj'
my_db = create_engine(mysql_db_url)

@app.route("/")
def index():
    return 'OK'


@app.route('/temp/insert', methods=['GET', 'POST'])
def temp_insert():
    try:
        dtime = request.args.get('dtime')
        if not dtime:
            return jsonify({'result':'NG', 'log':'lose dtime parameter'})

        temp = request.args.get('temp')
        if not temp:
            return jsonify({'result':'NG', 'log':'lose temp parameter'})

        table_name = 'temp_table'
        sql_cmd_str = "insert into %s (dtime, temp) values('%s', '%s')" %(table_name, dtime, temp)

        resultProxy = my_db.execute(sql_cmd_str)
        return jsonify({'result':'OK'})

    except Exception as e:
        print('--> exception: ' + str(e))
        return jsonify({'result':'NG', 'log':str(e)})

@app.route('/temp/read', methods=['GET', 'POST'])
def temp_read():
    try:
        # 先完成一次全部讀取就好

        table_name = 'temp_table'
        sql_cmd_str = "select * from %s ACS" %(table_name)

        resultProxy = my_db.execute(sql_cmd_str)
        data = resultProxy.fetchall()
        dtime_list = []
        temp_list = []
        for item in data:
            dtime_list.append(item['dtime'])
            temp_list.append(item['temp'])
        my_data = {'dtime':dtime_list, 'temp':temp_list}
        
        return jsonify({'result':'OK', 'data':my_data})

    except Exception as e:
        print('--> exception: ' + str(e))
        return jsonify({'result':'NG', 'log':str(e)})

@app.route('/temp/chart', methods=['GET', 'POST'])
def temp_chart():
    try:
        # 先完成一次全部讀取就好
        table_name = 'temp_table'
        sql_cmd_str = "select * from %s ACS" %(table_name)

        resultProxy = my_db.execute(sql_cmd_str)
        data = resultProxy.fetchall()
        dtime_list = []
        temp_list = []
        for item in data:
            dtime_list.append(item['dtime'])
            temp_list.append(item['temp'])
        my_data = {'dtime':dtime_list, 'temp':temp_list}
        
        #-- 畫圖
        font = FontProperties(fname=r"NotoSansTC-Regular.otf", size=14)

        plt.plot(dtime_list, temp_list)
        plt.title('溫度趨勢圖', fontproperties = font)
        plt.xlabel('時間', fontproperties = font)
        plt.ylabel('溫度', fontproperties = font)
        plt.xticks(dtime_list, rotation=90)
        plt.grid()
        #plt.show()

        plt.savefig('img.png')
        plt.close()
        return send_file('img.png', mimetype='image/png')

    except Exception as e:
        print('--> exception: ' + str(e))
        return jsonify({'result':'NG', 'log':str(e)})

if __name__ == "__main__":
    app.run(debug=True, port=8000)